<h2>Tambah Handphone</h2>

<form action="Handphone_proses.php" method="post">
    <table>

        <tr>
            <td>Nama Handphone</td>
            <td><input type="text" name="Nama_Handphone"></td>
        </tr>
        <tr>
            <td>Harga Handphone</td>
            <td><input type="text" name="hrg_Handphone"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>

