<h2>Tambah Komputer</h2>

<form action="Komputer_proses.php" method="post">
    <table>

        <tr>
            <td>Nama Komputer</td>
            <td><input type="text" name="nama_Komputer"></td>
        </tr>
        <tr>
            <td>Harga Komputer</td>
            <td><input type="text" name="hrg_Komputer"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>

