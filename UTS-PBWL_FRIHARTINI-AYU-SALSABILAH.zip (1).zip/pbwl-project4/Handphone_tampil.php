<?php

$mak = new App\Handphone;
$rows = $mak->tampil();

?>

<h2>Handphone</h2>

<a href="index.php?hal=Handphone_input" class="btn">Tambah Handphone</a>

<table>
    <tr>
        <th>ID Handphone</th>
        <th>Nama Handphone</th>
        <th>HARGA Handphone</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>
    <?php foreach ($rows as $row) { ?>
    <tr>
        <td><?php echo $row['id_Handphone']; ?></td>
        <td><?php echo $row['nama_Handphone']; ?></td>
        <td><?php echo $row['hrg_Handphone']; ?></td>
        <td><a href="index.php?hal=Handphone_edit&id=<?php echo $row['id_Handphone']; ?>" class="btn">Edit</a></td>
        <td><a href="index.php?hal=Handphone_delete&id=<?php echo $row['id_Handphone']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php } ?>
</table>
