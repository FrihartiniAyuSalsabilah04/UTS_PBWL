CREATE TABLE tb_Handphone (
  id_Handphone int(50) NOT NULL AUTO_INCREMENT,
  nama_Handphone varchar(100) NOT NULL,
  hrg_Handphone varchar(50) NOT NULL,
  PRIMARY KEY(id_Handphone)
);
CREATE TABLE tb_Komputer (
  id_Komputer int(50) NOT NULL AUTO_INCREMENT,
  nama_Komputer varchar(100) NOT NULL,
  hrg_Komputer varchar(50) NOT NULL,
  PRIMARY KEY(id_Komputer)
);
CREATE TABLE tb_Laptop (
  id_Laptop int(50) NOT NULL AUTO_INCREMENT,
  nama_Laptop varchar(100) NOT NULL,
  hrg_Laptop varchar(50) NOT NULL,
  PRIMARY KEY(id_Laptop)
);
