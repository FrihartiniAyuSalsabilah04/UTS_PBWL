<?php

require_once "inc/Koneksi.php";
require_once "app/Laptop.php";

$snc = new App\Laptop();

if (isset($_POST['btn_simpan'])) {
    $snc->simpan();
    header("location:index.php?hal=Laptop_tampil");
}

if (isset($_POST['btn_update'])) {
    $snc->update();
    header("location:index.php?hal=Laptop_tampil");
}