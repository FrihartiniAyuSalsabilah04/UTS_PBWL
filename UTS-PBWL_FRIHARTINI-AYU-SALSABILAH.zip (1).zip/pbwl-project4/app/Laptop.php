<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Laptop extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT * FROM tb_Laptop";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $nama_Laptop = $_POST['nama_Laptop'];
        $hrg_Laptop = $_POST['hrg_Laptop'];

        $sql = "INSERT INTO tb_Laptop (nama_Laptop, hrg_Laptop) VALUES (:nama_Laptop, :hrg_Laptop)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nama_Laptop", $nama_Laptop);
        $stmt->bindParam(":hrg_Laptop", $hrg_Laptop);
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT * FROM tb_Laptop WHERE id_Laptop=:id_Laptop";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_Laptop", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $nama_Laptop = $_POST['nama_Laptop'];
        $hrg_Laptop = $_POST['hrg_Laptop'];
        $id_Laptop = $_POST['id_Laptop'];

        $sql = "UPDATE tb_Laptop SET nama_Laptop=:nama_Laptop, hrg_Laptop=:hrg_Laptop WHERE id_Laptop=:id_Laptop";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nama_Laptop", $nama_Laptop);
        $stmt->bindParam(":hrg_Laptop", $hrg_Laptop);
        $stmt->bindParam(":id_Laptop", $id_Laptop);
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tb_Laptop WHERE id_Laptop=:id_Laptop";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_Laptop", $id);
        $stmt->execute();

    }

}