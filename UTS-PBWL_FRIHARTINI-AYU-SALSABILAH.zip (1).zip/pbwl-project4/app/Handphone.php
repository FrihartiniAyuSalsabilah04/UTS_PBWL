<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Handphone extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT * FROM tb_Handphone";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $nama_Handphone = $_POST['nama_Handphone'];
        $hrg_Handphone = $_POST['hrg_Handphone'];

        $sql = "INSERT INTO tb_Handphone (nama_Handphone, hrg_Handphone) VALUES (:nama_Handphone, :hrg_Handphone)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nama_Handphone", $nama_Handphone);
        $stmt->bindParam(":hrg_Handphone", $hrg_Handphone);
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT * FROM tb_Handphone WHERE id_Handphone=:id_Handphone";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_Handphone", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $Nama_Handphone = $_POST['Nama_Handphone'];
        $hrg_Handphone = $_POST['hrg_Handphone'];
        $id_Handphone = $_POST['id_Handphone'];

        $sql = "UPDATE tb_Handphone SET Nama_Handphone=:Nama_Handphone, hrg_Handphone=:hrg_Handphone WHERE id_Handphone=:id_Handphone";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":Nama_Handphone", $Nama_Handphone);
        $stmt->bindParam(":hrg_Handphone", $hrg_Handphone);
        $stmt->bindParam(":id_Handphone", $id_Handphone);
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tb_Handphone WHERE id_Handphone=:id_Handphone";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_Handphone", $id);
        $stmt->execute();

    }

}