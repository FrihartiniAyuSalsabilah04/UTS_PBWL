<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Komputer extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT * FROM tb_Komputer";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $nama_Komputer = $_POST['nama_Komputer'];
        $hrg_Komputer = $_POST['hrg_Komputer'];

        $sql = "INSERT INTO tb_Komputer (nama_Komputer, hrg_Komputer) VALUES (:nama_Komputer, :hrg_Komputer)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nama_Komputer", $nama_Komputer);
        $stmt->bindParam(":hrg_Komputer", $hrg_Komputer);
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT * FROM tb_Komputer WHERE id_Komputer=:id_Komputer";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_Komputer", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $nama_Komputer = $_POST['nama_Komputer'];
        $hrg_Komputer = $_POST['hrg_Komputer'];
        $id_Komputer = $_POST['id_Komputer'];

        $sql = "UPDATE tb_Komputer SET nama_Komputer=:nama_Komputer, hrg_Komputer=:hrg_Komputer WHERE id_Komputer=:id_Komputer";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nama_Komputer", $nama_Komputer);
        $stmt->bindParam(":hrg_Komputer", $hrg_Komputer);
        $stmt->bindParam(":id_Komputer", $id_Komputer);
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tb_Komputer WHERE id_Komputer=:id_Komputer";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_Komputer", $id);
        $stmt->execute();

    }

}