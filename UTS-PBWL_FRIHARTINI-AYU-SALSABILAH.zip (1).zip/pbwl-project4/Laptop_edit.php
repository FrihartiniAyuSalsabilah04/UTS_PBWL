<?php

$id = $_GET['id'];
$snc = new App\Laptop();

$row = $snc->edit($id);
?>

<h2>Edit Laptop</h2>

<form action="Laptop_proses.php" method="post">
    <input type="hidden" name="id_Laptop" value="<?php echo $row['id_Laptop']; ?>">
    <table>
        <tr>
            <td>Nama Laptop</td>
            <td><input type="text" name="nama_Laptop" value="<?php echo $row['nama_Laptop']; ?>"></td>
        </tr>
        <tr>
            <td>Harga Laptop</td>
            <td><input type="text" name="hrg_Laptop" value="<?php echo $row['hrg_Laptop']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_update" value="UPDATE"></td>
        </tr>
    </table>
</form>