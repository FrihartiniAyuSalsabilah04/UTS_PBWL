<?php

$id = $_GET['id'];

$snc = new App\Laptop();
$rows = $snc->delete($id);

?>

<div class="info">
      Data berhasil dihapus!
      <a href="index.php?=Laptop_tampil">Kembali</a>
</div>