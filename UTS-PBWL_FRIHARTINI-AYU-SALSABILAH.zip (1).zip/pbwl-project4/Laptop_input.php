<h2>Tambah Laptop</h2>

<form action="Laptop_proses.php" method="post">
    <table>

        <tr>
            <td>Nama Laptop</td>
            <td><input type="text" name="nama_Laptop"></td>
        </tr>
        <tr>
            <td>Harga Laptop</td>
            <td><input type="text" name="hrg_Laptop"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>

