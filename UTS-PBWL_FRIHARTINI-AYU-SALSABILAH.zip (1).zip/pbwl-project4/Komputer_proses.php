<?php

require_once "inc/Koneksi.php";
require_once "app/Komputer.php";

$min = new App\Komputer();

if (isset($_POST['btn_simpan'])) {
    $min->simpan();
    header("location:index.php?hal=Komputer_tampil");
}

if (isset($_POST['btn_update'])) {
    $min->update();
    header("location:index.php?hal=Komputer_tampil");
}