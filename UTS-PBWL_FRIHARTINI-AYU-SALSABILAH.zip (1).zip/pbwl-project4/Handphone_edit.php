<?php

$id = $_GET['id'];
$mak= new App\Handphone();

$row = $mak->edit($id);
?>

<h2>Edit Handphone</h2>

<form action="Handphone_proses.php" method="post">
    <input type="hidden" name="id_Handphone" value="<?php echo $row['id_Handphone']; ?>">
    <table>
        <tr>
            <td>Nama Handphone</td>
            <td><input type="text" name="nama_Handphone" value="<?php echo $row['nama_Handphone']; ?>"></td>
        </tr>
        <tr>
            <td>Harga Handphone</td>
            <td><input type="text" name="hrg_Handphone" value="<?php echo $row['hrg_Handphone']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_update" value="UPDATE"></td>
        </tr>
    </table>
</form>