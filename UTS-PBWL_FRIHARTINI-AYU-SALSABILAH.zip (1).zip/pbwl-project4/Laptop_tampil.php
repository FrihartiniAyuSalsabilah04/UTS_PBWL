<?php

$sna = new App\Laptop;
$rows = $sna->tampil();

?>

<h2>Laptop</h2>

<a href="index.php?hal=Laptop_input" class="btn">Tambah Laptop</a>

<table>
    <tr>
        <th>ID Laptop</th>
        <th>NAMA Laptop</th>
        <th>HARGA Laptop</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>
    <?php foreach ($rows as $row) { ?>
    <tr>
        <td><?php echo $row['id_Laptop']; ?></td>
        <td><?php echo $row['nama_Laptop']; ?></td>
        <td><?php echo $row['hrg_Laptop']; ?></td>
        <td><a href="index.php?hal=Laptop_edit&id=<?php echo $row['id_Laptop']; ?>" class="btn">Edit</a></td>
        <td><a href="index.php?hal=Laptop_delete&id=<?php echo $row['id_Laptop']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php } ?>
</table>
