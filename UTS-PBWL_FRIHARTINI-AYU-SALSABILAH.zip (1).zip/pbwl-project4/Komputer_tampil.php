<?php

$min = new App\Komputer;
$rows = $min->tampil();

?>

<h2>Komputer</h2>

<a href="index.php?hal=Komputer_input" class="btn">Tambah Komputer</a>

<table>
    <tr>
        <th>ID Komputer</th>
        <th>NAMA Komputer</th>
        <th>HARGA Komputer</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>
    <?php foreach ($rows as $row) { ?>
    <tr>
        <td><?php echo $row['id_Komputer']; ?></td>
        <td><?php echo $row['nama_Komputer']; ?></td>
        <td><?php echo $row['hrg_Komputer']; ?></td>
        <td><a href="index.php?hal=Komputer_edit&id=<?php echo $row['id_Komputer']; ?>" class="btn">Edit</a></td>
        <td><a href="index.php?hal=Komputer_delete&id=<?php echo $row['id_Komputer']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php } ?>
</table>
